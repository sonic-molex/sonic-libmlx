import sys
import glob
import math
import syslog
import threading

from .HalPlatformApi import Client

from thrift import Thrift
from thrift.Thrift import TApplicationException
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.transport.TTransport import TTransportException
from thrift.protocol import TBinaryProtocol


# One Thrift Client+Transport per thread. The generated sync Client is not
# safe to share across threads on a single TCP stream.
_tls = threading.local()


def _close():
    transport = getattr(_tls, 'transport', None)
    if transport is not None:
        try:
            transport.close()
        except Exception:
            pass
    _tls.transport = None
    _tls.client = None


def _open():
    sock = TSocket.TSocket('127.0.0.1', 10972)
    transport = TTransport.TBufferedTransport(sock)
    protocol = TBinaryProtocol.TBinaryProtocol(transport)
    client = Client(protocol)
    transport.open()
    _tls.transport = transport
    _tls.client = client


def Initialize():
    '''
    Open a HalPlatformApi thrift connection for the calling thread.

    Returns:
        A boolean, True if initialized successfully, False if not
    '''
    try:
        _close()
        _open()
        return True
    except Thrift.TException as tx:
        print('%s' % getattr(tx, 'message', tx))
        _close()
        return False


def Destroy():
    """Close this thread's thrift connection."""
    _close()


def _rpc(method_name, *args):
    """
    Invoke a thrift method on this thread's client.

    Lazily opens a connection if Initialize() was not called on this thread
    (e.g. thermalctld worker threads after Chassis init on the main thread).
    On transport errors, reconnect once and retry.
    """
    client = getattr(_tls, 'client', None)
    if client is None:
        if not Initialize():
            return None
        client = getattr(_tls, 'client', None)
        if client is None:
            return None
    try:
        return getattr(client, method_name)(*args)
    except (TTransportException, TApplicationException, Thrift.TException) as exc:
        syslog.syslog(
            syslog.LOG_WARNING,
            'HalPlatformApi %s failed (%s), reconnecting once' % (method_name, exc))
        try:
            _close()
            _open()
            return getattr(_tls.client, method_name)(*args)
        except Exception:
            _close()
            raise


def _none_if_nan(value):
    """Return None when the server sends a quiet NaN, so SONiC shows N/A."""
    if isinstance(value, float) and math.isnan(value):
        return None
    return value


def _none_if_negative(value):
    """Return None when an i32 getter sends a negative value, so SONiC shows N/A."""
    if value is not None and value < 0:
        return None
    return value


# PSU

def PsuGetModel(name):
    '''
    Retrieves the model number (or part number) of the device

    Args:
        name: A string, the device name
    Returns:
        A string, model/part number of device, None if operation failed
    '''
    return _rpc('PsuGetModel', name)


def PsuGetSerial(name):
    '''
    Retrieves the serial number of the device

    Args:
        name: A string, the device name
    Returns:
        A string, serial number of device, None if operation failed
    '''
    return _rpc('PsuGetSerial', name)


def PsuGetRevision(name):
    '''
    Retrieves the hardware revision of the device

    Args:
        name: A string, the device name
    Returns:
        A string, revision value of device, None if operation failed
    '''
    return _rpc('PsuGetRevision', name)


def PsuGetPresence(name):
    '''
    Retrieves the presence of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is present, False if not
    '''
    return _rpc('PsuGetPresence', name)


def PsuGetStatus(name):
    '''
    Retrieves the operational status of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is operating properly, False if not
    '''
    return _rpc('PsuGetStatus', name)


def PsuIsReplaceable(name):
    '''
    Indicate whether this device is replaceable.

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if it is replaceable, False if not
    '''
    return _rpc('PsuIsReplaceable', name)


def PsuGetVoltage(name):
    '''
    Retrieves current PSU voltage output

    Args:
        name: A string, the device name
    Returns:
        A float number, the output voltage in volts, e.g. 12.1
    '''
    return _none_if_nan(_rpc('PsuGetVoltage', name))


def PsuGetCurrent(name):
    '''
    Retrieves present electric current supplied by PSU

    Args:
        name: A string, the device name
    Returns:
        A float number, the electric current in amperes, e.g 15.4
    '''
    return _none_if_nan(_rpc('PsuGetCurrent', name))


def PsuGetPower(name):
    '''
    Retrieves current energy supplied by PSU

    Args:
        name: A string, the device name
    Returns:
        A float number, the power in watts, e.g. 302.6
    '''
    return _none_if_nan(_rpc('PsuGetPower', name))


def PsuGetTemp(name):
    '''
    Retrieves current temperature reading from PSU

    Args:
        name: A string, the device name
    Returns:
        A float number of current temperature in Celsius, e.g. 30.1
    '''
    return _none_if_nan(_rpc('PsuGetTemp', name))


def PsuGetInputVoltage(name):
    '''
    Retrieves current PSU voltage input

    Args:
        name: A string, the device name
    Returns:
        A float number, the input voltage in volts, e.g. 12.1
    '''
    return _none_if_nan(_rpc('PsuGetInputVoltage', name))


def PsuGetInputCurrent(name):
    '''
    Retrieves the input current draw of the power supply

    Args:
        name: A string, the device name
    Returns:
        A float number, the electric current in amperes, e.g 15.4
    '''
    return _none_if_nan(_rpc('PsuGetInputCurrent', name))


def PsuGetLedState(name):
    '''
    Gets the state of the PSU status LED

    Args:
        name: A string, the device name
    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('PsuGetLedState', name)


def PsuSetLedState(name, color):
    '''
    Sets the state of the PSU status LED

    Args:
        name: A string, the device name
        color: A string representing the color with which to set the PSU status LED
    Returns:
        A bool, True if status LED state is set successfully, False if not
    '''
    return _rpc('PsuSetLedState', name, color)


# FAN

def FanGetModel(name):
    '''
    Retrieves the model number (or part number) of the device

    Args:
        name: A string, the device name
    Returns:
        A string, model/part number of device, None if operation failed
    '''
    return _rpc('FanGetModel', name)


def FanGetSerial(name):
    '''
    Retrieves the serial number of the device

    Args:
        name: A string, the device name
    Returns:
        A string, serial number of device, None if operation failed
    '''
    return _rpc('FanGetSerial', name)


def FanGetRevision(name):
    '''
    Retrieves the hardware revision of the device

    Args:
        name: A string, the device name
    Returns:
        A string, revision value of device, None if operation failed
    '''
    return _rpc('FanGetRevision', name)


def FanGetPresence(name):
    '''
    Retrieves the presence of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is present, False if not
    '''
    return _rpc('FanGetPresence', name)


def FanGetStatus(name):
    '''
    Retrieves the operational status of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is operating properly, False if not
    '''
    return _rpc('FanGetStatus', name)


def FanIsReplaceable(name):
    '''
    Indicate whether this device is replaceable.

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if it is replaceable, False if not
    '''
    return _rpc('FanIsReplaceable', name)


def FanGetDirection(name):
    '''
    Retrieves the direction of fan

    Args:
        name: A string, the device name
    Returns:
        A string, either FAN_DIRECTION_INTAKE or FAN_DIRECTION_EXHAUST depending on fan direction
    '''
    return _rpc('FanGetDirection', name)


def FanGetSpeed(name):
    '''
    Retrieves the speed of fan as a percentage of full speed

    Args:
        name: A string, the device name
    Returns:
        An integer, the percentage of full fan speed, in the range 0 (off) to 100 (full speed).
        None if the value is negative.
    '''
    return _none_if_negative(_rpc('FanGetSpeed', name))


def FanGetTargetSpeed(name):
    '''
    Retrieves the target (expected) speed of the fan

    Args:
        name: A string, the device name
    Returns:
        An integer, the percentage of full fan speed, in the range 0 (off) to 100 (full speed)
    '''
    return _none_if_negative(_rpc('FanGetTargetSpeed', name))


def FanGetSpeedTolerance(name):
    '''
    Retrieves the speed tolerance of the fan

    Args:
        name: A string, the device name
    Returns:
        An integer, the percentage of variance from target speed which is considered tolerable
    '''
    return _none_if_negative(_rpc('FanGetSpeedTolerance', name))


def FanSetSpeed(name, speed):
    '''
    Sets the fan speed

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if speed is set successfully, False if not
    '''
    return _rpc('FanSetSpeed', name, speed)

def FanSetSubIndexSpeed(name, speed):
    '''
    Sets the fan speed

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if speed is set successfully, False if not
    '''
    return _rpc('FanSetSubIndexSpeed', name, speed)

def FanGetLedState(name):
    '''
    Gets the state of the fan status LED

    Args:
        name: A string, the device name
    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('FanGetLedState', name)


def FanSetLedState(name, color):
    '''
    Sets the state of the fan module status LED

    Args:
        name: A string, the device name
        color: A string representing the color with which to set the fan module status LED
    Returns:
        A boolean, True if status LED state is set successfully, False if not
    '''
    return _rpc('FanSetLedState', name, color)


def FanGetPositionInParent(name):
    '''
    Retrieves 1-based relative physical position in parent device.
    Returns:
        integer: The 1-based relative physical position in parent
        device or -1 if cannot determine the position
    '''
    return _none_if_negative(_rpc('FanGetPositionInParent', name))



# FAN Drawer
def FanDrawerGetPresence(name):
    '''
    Retrieves the presence of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is present, False if not
    '''
    return _rpc('FanDrawerGetPresence', name)


def FanDrawerGetStatus(name):
    '''
    Retrieves the operational status of the device

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if device is operating properly, False if not
    '''
    return _rpc('FanDrawerGetStatus', name)


def FanDrawerIsReplaceable(name):
    '''
    Indicate whether this device is replaceable.

    Args:
        name: A string, the device name
    Returns:
        A boolean, True if it is replaceable, False if not
    '''
    return _rpc('FanDrawerIsReplaceable', name)


def FanDrawerGetLedState(name):
    '''
    Gets the state of the fan drawer status LED

    Args:
        name: A string, the device name
    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('FanDrawerGetLedState', name)


def FanDrawerSetLedState(name, color):
    '''
    Sets the state of the fan drawer status LED

    Args:
        name: A string, the device name
        color: A string representing the color with which to set the fan module status LED
    Returns:
        A boolean, True if status LED state is set successfully, False if not
    '''
    return _rpc('FanDrawerSetLedState', name, color)


# LED
def LedGetState(name):
    '''
    Gets the state of the LED device

    Args:
        name: A string, the device name
    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('LedGetState', name)


def LedSetState(name, state):
    '''
    Sets the state of the LED device

    Args:
        name: A string, the device name
        color: A string representing the color with which to set the fan module status LED
    Returns:
        A boolean, True if status LED state is set successfully, False if not
    '''
    return _rpc('LedSetState', name, state)


# THERMAL
def ThermalGetTemp(name):
    '''
    Retrieves current temperature reading from thermal

    Args:
        name: A string, the device name
    Returns:
        A float number of current temperature in Celsius, e.g. 30.1.
        None if the HAL client is down or the server returns NaN (sensor
        absent or unreadable), so SONiC can show N/A.
    '''
    return _none_if_nan(_rpc('ThermalGetTemp', name))


def ThermalGetHighThreshold(name):
    '''
    Retrieves the high threshold temperature of thermal

    Returns:
        A float number, the high threshold temperature of thermal in
        Celsius up to nearest thousandth of one degree Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetHighThreshold', name))


def ThermalGetLowThreshold(name):
    '''
    Retrieves the low threshold temperature of thermal

    Returns:
        A float number, the low threshold temperature of thermal in
        Celsius up to nearest thousandth of one degree Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetLowThreshold', name))


def ThermalSetHighThreshold(name, temperature):
    '''
    Sets the high threshold temperature of thermal

    Args :
        temperature: A float number up to nearest thousandth of one
        degree Celsius, e.g. 30.125
    Returns:
        A boolean, True if threshold is set successfully, False if not
    '''
    return _rpc('ThermalSetHighThreshold', name, temperature)


def ThermalSetLowThreshold(name, temperature):
    '''
    Sets the low threshold temperature of thermal

    Args :
        temperature: A float number up to nearest thousandth of one
        degree Celsius, e.g. 30.125
    Returns:
        A boolean, True if threshold is set successfully, False if not
    '''
    return _rpc('ThermalSetLowThreshold', name, temperature)


def ThermalGetHighCriticalThreshold(name):
    '''
    Retrieves the high critical threshold temperature of thermal

    Returns:
        A float number, the high critical threshold temperature of
        thermal in Celsius up to nearest thousandth of one degree
        Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetHighCriticalThreshold', name))


def ThermalGetLowCriticalThreshold(name):
    '''
    Retrieves the low critical threshold temperature of thermal

    Returns:
        A float number, the low critical threshold temperature of thermal in Celsius
        up to nearest thousandth of one degree Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetLowCriticalThreshold', name))


def ThermalSetHighCriticalThreshold(name, temperature):
    '''
    Sets the critical high threshold temperature of thermal

    Args :
        temperature: A float number up to nearest thousandth of one degree Celsius,
        e.g. 30.125

    Returns:
        A boolean, True if threshold is set successfully, False if not
    '''
    return _rpc('ThermalSetHighCriticalThreshold', name, temperature)


def ThermalSetLowCriticalThreshold(name, temperature):
    '''
    Sets the critical low threshold temperature of thermal

    Args :
        temperature: A float number up to nearest thousandth of one degree Celsius,
        e.g. 30.125

    Returns:
        A boolean, True if threshold is set successfully, False if not
    '''
    return _rpc('ThermalSetLowCriticalThreshold', name, temperature)


def ThermalGetMinimumRecorded(name):
    '''
    Retrieves the minimum recorded temperature of thermal

    Returns:
        A float number, the minimum recorded temperature of thermal in Celsius
        up to nearest thousandth of one degree Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetMinimumRecorded', name))


def ThermalGetMaximumRecorded(name):
    '''
    Retrieves the maximum recorded temperature of thermal

    Returns:
        A float number, the maximum recorded temperature of thermal in Celsius
        up to nearest thousandth of one degree Celsius, e.g. 30.125
    '''
    return _none_if_nan(_rpc('ThermalGetMaximumRecorded', name))


# watch dog
def WatchDogArm(index, seconds):
    return _rpc('WatchDogArm', index, seconds)


def WatchDogDisrm(index):
    return _rpc('WatchDogDisrm', index)


def WatchDogIsArmed(index):
    return _rpc('WatchDogIsArmed', index)


# Chassis
def ChassisGetName():
    '''
    Retrieves the model name of the device

    Returns:
        A string, name of the device, None if operation failed
    '''
    return _rpc('ChassisGetName')


def ChassisGetModel():
    '''
    Retrieves the model number (or part number) of the device

    Returns:
        A string, model/part number of device, None if operation failed
    '''
    return _rpc('ChassisGetModel')


def ChassisGetSerial():
    '''
    Retrieves the serial number of the device

    Returns:
        A string, serial number of device, None if operation failed
    '''
    return _rpc('ChassisGetSerial')


def ChassisGetRevision():
    '''
    Retrieves the hardware revision of the device

    Returns:
        A string, revision value of device, None if operation failed
    '''
    return _rpc('ChassisGetRevision')


def ChassisGetBaseMac():
    '''
    Retrieves the base MAC address for the chassis

    Returns:
        A string containing the MAC address in the format 'XX:XX:XX:XX:XX:XX'
    '''
    return _rpc('ChassisGetBaseMac')


def ChassisGetMfgJson():
    '''
    Retrieves full chassis manufacturing info as JSON (show mfg chassis).

    Returns:
        A JSON string with Manufacturer/ProductName/SN/PN/... fields, or None
    '''
    return _rpc('ChassisGetMfgJson')


def ChassisGetSlot():
    '''
    Retrieves the physical-slot of this module in the modular chassis.

    Returns:
        An integer, the vendor specific physical slot identifier of this module in the modular-chassis.
    '''
    return _none_if_negative(_rpc('ChassisGetSlot'))


def ChassisGetLedState():
    '''
    Gets the state of the system LED

    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('ChassisGetLedState')


def ChassisSetLedState(color):
    '''
    Sets the state of the system LED

    Args:
        color: A string representing the color with which to set the fan module status LED
    Returns:
        A boolean, True if status LED state is set successfully, False if not
    '''
    return _rpc('ChassisSetLedState', color)


def ChassisGetList():
    '''
    Retrieves the chassis configuration, like platform.json

    Returns:
        A string containing chassis configuration, json format
    '''
    return _rpc('ChassisGetList')


def ChassisIsModular():
    '''
    Retrieves whether the sonic instance is part of modular chassis

    Returns:
        A bool value, should return False by default or for fixed-platforms.
        Should return True for supervisor-cards, line-cards etc running as part
        of modular-chassis.
    '''
    return _rpc('ChassisIsModular')


def ModuleGetModel(name):
    '''
    Retrieves the firmware version of the component

    Note: the firmware version will be read from HW

    Args:
        name: A string, the device name
    Returns:
        A string containing the firmware version of the component
    '''
    return _rpc('ModuleGetModel', name)


def ModuleGetSerial(name):
    '''
    Retrieves the serial number of the device

    Args:
        name: A string, the device name
    Returns:
        A string, serial number of device, None if operation failed
    '''
    return _rpc('ModuleGetSerial', name)


def ModuleGetRevision(name):
    '''
    Retrieves the hardware revision of the device

    Args:
        name: A string, the device name
    Returns:
        A string, revision value of device, None if operation failed
    '''
    return _rpc('ModuleGetRevision', name)


def ModuleGetBaseMac(name):
    '''
    Retrieves the base MAC address for the chassis

    Args:
        name: A string, the device name
    Returns:
        A string containing the MAC address in the format 'XX:XX:XX:XX:XX:XX'
    '''
    return _rpc('ModuleGetBaseMac', name)


def ModuleGetMfgJson(name):
    '''
    Retrieves full module manufacturing info as JSON (show mfg scc / linecard).

    Args:
        name: A string, the device name (e.g. SUPERVISOR0)
    Returns:
        A JSON string with Manufacturer/ProductName/SN/PN/MAC... fields, or None
    '''
    return _rpc('ModuleGetMfgJson', name)


def ModuleReset(name, reset_type):
    '''
    Reset a line-card module via SLOT_Reset.

    Args:
        name: A string, the module name (e.g. LINE-CARD1)
        reset_type: An integer RST_MODE_* (WARM=1, COLD=2)

    Returns:
        An integer: 0 indicates success; any non-zero value indicates failure
    '''
    return _rpc('ModuleReset', name, reset_type)


def ModuleSetPowerEnable(name, enable):
    '''
    Enable/disable whole-card power via Comp_SLOT_SetPowerEnable.

    Args:
        name: A string, the module name (e.g. LINE-CARD1)
        enable: A bool, True to power on, False to power off

    Returns:
        An integer: 0 indicates success; any non-zero value indicates failure
    '''
    return _rpc('ModuleSetPowerEnable', name, bool(enable))


def ModuleGetPowerEnable(name):
    '''
    Query whole-card power-control bit via Comp_SLOT_GetPowerEnable.

    Args:
        name: A string, the module name (e.g. LINE-CARD1)

    Returns:
        An integer: 1 = enabled, 0 = disabled, <0 = error
    '''
    return _rpc('ModuleGetPowerEnable', name)


def ModuleGetSlot(name):
    '''
    Retrieves the platform vendor's slot number of the module

    Args:
        name: A string, the device name
    Returns:
        An integer, indicating the slot number in the chassis
    '''
    return _none_if_negative(_rpc('ModuleGetSlot', name))


def ModuleGetType(name):
    '''
    Retrieves the type of the module.

    Args:
        name: A string, the device name
    Returns:
        A string, the module-type from one of the predefined types:
        MODULE_TYPE_SUPERVISOR, MODULE_TYPE_LINE or MODULE_TYPE_FABRIC
    '''
    return _rpc('ModuleGetType', name)


def ModuleGetStatus(name):
    '''
    Retrieves the operational status of the module

    Args:
        name: A string, the device name
    Returns:
        A string, the operational status of the module from one of the
        predefined status values: MODULE_STATUS_EMPTY, MODULE_STATUS_OFFLINE,
        MODULE_STATUS_FAULT, MODULE_STATUS_PRESENT or MODULE_STATUS_ONLINE
    '''
    return _rpc('ModuleGetStatus', name)


def ModuleGetTemp(name):
    '''
    Retrieves current temperature reading from thermal

    Args:
        name: A string, the device name
    Returns:
        A float number of current temperature in Celsius, e.g. 30.1
    '''
    return _none_if_nan(_rpc('ModuleGetTemp', name))


def ModuleGetLedState(name):
    '''
    Gets the state of the module LED

    Returns:
        A string, one of the predefined strings in LedConvert
    '''
    return _rpc('ModuleGetLedState', name)


def ModuleSetLedState(name, color):
    '''
    Sets the state of the module status LED

    Args:
        name: A string, the device name
        color: A string representing the color with which to set the module status LED
    Returns:
        A bool, True if status LED state is set successfully, False if not
    '''
    return _rpc('ModuleSetLedState', name, color)



def ComponentGetMfgJson(name):
    '''
    Retrieves full component manufacturing info as JSON (e.g. SSD).

    Args:
        name: A string, the component name (e.g. SSD / ssd)
    Returns:
        A JSON string with Manufacturer/ProductName/SN/PN/... fields, or None
    '''
    return _rpc('ComponentGetMfgJson', name)


def ComponentGetFwVer(name):
    '''
    Retrieves the firmware version of the component

    Note: the firmware version will be read from HW

    Args:
        name: A string, the device name
    Returns:
        A string containing the firmware version of the component
    '''
    return _rpc('ComponentGetFwVer', name)

def ComponentUpgrade(name, image_path):
    '''
    Upgrades the specified component using the provided image path.

    Note: the upgrade process will be triggered remotely via RPC

    Args:
        name: A string, the name of the component to upgrade
        image_path: A string, the path to the upgrade image

    Returns:
        An integer: 0 indicates success; any non-zero value indicates failure
    '''
    return _rpc('ComponentUpgrade', name, image_path)

def ComponentGetUpgradeStatus(name):
    '''
    Retrieves the upgrade status of the specified component.

    Note: this checks whether the component has been successfully upgraded

    Args:
        name: A string, the name of the component

    Returns:
        An integer: 0 indicates upgrade completed; any non-zero value indicates failure or incomplete status
    '''
    return _rpc('ComponentGetUpgradeStatus', name)

def ComponentReset(name, reset_type):
    '''
    Resets the specified component using the given reset type.

    Note: reset_type may represent different reset modes (e.g., soft or hard reset)

    Args:
        name: A string, the name of the component
        reset_type: An integer, the type of reset to perform

    Returns:
        An integer: 0 indicates success; any non-zero value indicates failure
    '''
    return _rpc('ComponentReset', name, reset_type)

def ComponentSwitch(name):
    return _rpc('ComponentSwitch', name)

def ComponentCommit(name):
    return _rpc('ComponentCommit', name)

def ComponentTypeGet(name):
    return _rpc('ComponentTypeGet', name)



