/*****************************************************************************************************
   Copyright (C) 2012, Oplink Communications Inc.
   FileName:      DevData.h
   Author:        Zhen Zhang
   Date:          2018-06-01
   Version:       1.0
   Description:
   Function List:

   History:
   [Zhen Zhang] [2018-06-01] [1.0] [Creator]


*****************************************************************************************************/

#ifndef _DEV_PAM4_DATA__
#define _DEV_PAM4_DATA__

#ifdef __cplusplus
extern "C" {
#endif

/* Pam4 */
struct CPam4StatusData
{

};

struct CPam4CfgData
{

};


#ifdef __cplusplus
};
#endif

#endif



