/*****************************************************************************************************
   Copyright (C) 2012, Oplink Communications Inc.
   FileName:      DevData.h
   Author:        Zhen Zhang
   Date:          2018-06-01
   Version:       1.0
   Description:
   Function List:

   History:
   [Zhen Zhang] [2018-06-01] [1.0] [Creator]


*****************************************************************************************************/

#ifndef _DEV_DCE_DATA__
#define _DEV_DCE_DATA__

#ifdef __cplusplus
extern "C" {
#endif

/* DCE */
struct CDceStatusData
{

};

struct CDceCfgData
{

};



#ifdef __cplusplus
};
#endif

#endif



